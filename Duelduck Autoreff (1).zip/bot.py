﻿import os
import sys
import json
import base64
import base58
import requests
from datetime import datetime
from solana.keypair import Keypair
from nacl.signing import SigningKey
from colorama import init, Fore, Style
import pyfiglet

init(autoreset=True)

RESET = Style.RESET_ALL
BOLD = Style.BRIGHT
YELLOW = Fore.YELLOW + BOLD
GREEN = Fore.GREEN + BOLD
RED = Fore.RED + BOLD
CYAN = Fore.CYAN + BOLD
MAGENTA = Fore.MAGENTA + BOLD

WALLETS_FILE = "wallets.json"
API_URL = "https://api.duelduck.com/auth/sign-in-wallet"

def clear_screen():
    os.system("cls" if os.name == "nt" else "clear")

def set_title():
    sys.stdout.write("\x1b]2;Duelduck Autoreff by : 佐賀県産 (YUURI)\x1b\\")
    sys.stdout.flush()

def banner():
    clear_screen()
    ascii_art = pyfiglet.figlet_format("Yuurisandesu", font="standard")
    print(CYAN + ascii_art + RESET)
    print(MAGENTA + "Welcome to Yuuri, Duelduck Autoreff" + RESET)
    print(GREEN + "Ready to hack the world?" + RESET)
    print(f"{YELLOW}Current time: {datetime.now().strftime('%d-%m-%Y %H:%M:%S')}{RESET}\n")

def load_wallets():
    if os.path.exists(WALLETS_FILE):
        with open(WALLETS_FILE, "r") as f:
            return json.load(f)
    return []

def save_wallet(address, secret_key_base58):
    wallets = load_wallets()
    wallets.append({"address": address, "private_key": secret_key_base58})
    with open(WALLETS_FILE, "w") as f:
        json.dump(wallets, f, indent=4)
    print(GREEN + "Wallet successfully saved to wallets.json" + RESET)

def register_wallet(referrer_token, num_wallets=1):
    for i in range(num_wallets):
        print(YELLOW + f"Creating new wallet {i+1}" + RESET)
        
        keypair = Keypair()
        address = str(keypair.public_key)
        secret_key_bytes = bytes(keypair.secret_key)
        secret_key_base58 = base58.b58encode(secret_key_bytes).decode('utf-8')
        
        message = address.encode('utf-8')
        
        signing_key = SigningKey(secret_key_bytes[:32])
        signed = signing_key.sign(message)
        signature_b64 = base64.b64encode(signed.signature).decode('utf-8')
        
        print(YELLOW + f"Address {address}" + RESET)
        
        payload = {
            "address": address,
            "secret": signature_b64,
            "referrer_token": referrer_token,
            "chain_type": 0,
            "name": "Phantom"
        }
        
        try:
            response = requests.post(API_URL, json=payload, headers={"Content-Type": "application/json"})
            if response.status_code == 200:
                data = response.json()
                balance = data.get("user", {}).get("balance", "N/A")
                print(GREEN + f"Sign-in successful Balance {balance}" + RESET)
                save_wallet(address, secret_key_base58)
            else:
                print(RED + f"Failed Status {response.status_code}" + RESET)
                print(RED + f"Response {response.text[:300]}" + RESET)
        except Exception as e:
            print(RED + f"Connection error {str(e)}" + RESET)
        
        print("")

if __name__ == "__main__":
    set_title()
    banner()
    
    ref_token = input(YELLOW + "Enter Referral Token " + RESET).strip()
    if not ref_token:
        print(RED + "Referral token is required" + RESET)
        input(YELLOW + "Press Enter to exit..." + RESET)
        sys.exit()
    
    try:
        jumlah = int(input(YELLOW + "How many wallets to create " + RESET) or "1")
        if jumlah < 1:
            jumlah = 1
    except:
        jumlah = 1
    
    print(YELLOW + f"Starting to create {jumlah} new wallets" + RESET)
    print("")
    
    register_wallet(ref_token, jumlah)
    
    print(GREEN + "All done Saved wallets are in wallets.json" + RESET)
    input(YELLOW + "Press Enter to exit..." + RESET)