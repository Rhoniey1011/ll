require "net/http"
require "uri"
require "json"
require "artii"

GREEN = "\e[32;1m"
YELLOW = "\e[33;1m"
RED = "\e[31;1m"
CYAN = "\e[36;1m"
MAGENTA = "\e[35;1m"
BOLD = "\e[1m"
RESET = "\e[0m"

def log_green(message)
  puts GREEN + BOLD + message + RESET
end

def log_yellow(message)
  puts YELLOW + BOLD + message + RESET
end

def log_red(message)
  puts RED + BOLD + message + RESET
end

def clear_screen
  if RUBY_PLATFORM.include?("mswin") || RUBY_PLATFORM.include?("mingw") || RUBY_PLATFORM.include?("cygwin")
    system("cls")
  else
    system("clear")
  end
end

def banner
  clear_screen
  artii = Artii::Base.new(:font => "standard")
  ascii_art = artii.asciify("Yuurisandesu")
  puts CYAN + BOLD + ascii_art + RESET
  puts
  puts MAGENTA + BOLD + "Welcome to Yuuri, Cryptowave" + RESET
  log_green("Ready to hack the world?")
  time_str = Time.now.strftime("%d-%m-%Y %H:%M:%S")
  puts YELLOW + BOLD + "Current time: " + time_str + RESET
  puts
end

def set_title
  STDOUT.write("\e]2;Cryptowave by : 佐賀県産 (YUURI)\a")
  STDOUT.flush
end

def generate_random_email
  chars = "abcdefghijklmnopqrstuvwxyz0123456789"
  local = ""
  12.times do
    local << chars[rand(chars.length)]
  end
  local + "@gmail.com"
end

def generate_random_password(length = 12)
  chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.!"
  result = ""
  length.times do
    result << chars[rand(chars.length)]
  end
  result
end

def generate_display_name
  base = "Yuuri"
  chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
  suffix = ""
  6.times do
    suffix << chars[rand(chars.length)]
  end
  base + suffix
end

def request_referral_code
  default_code = "EARNA76F7F"
  print YELLOW + BOLD + "Referral code: " + RESET
  line = STDIN.gets
  return default_code if line.nil?
  value = line.strip
  if value.empty?
    log_yellow("Referral code input is empty, default value will be used")
    default_code
  else
    value
  end
end

def request_account_count
  loop do
    print YELLOW + BOLD + "Number of accounts to generate: " + RESET
    line = STDIN.gets
    if line.nil?
      log_red("Input stream is not available")
      next
    end
    raw = line.strip
    begin
      value = Integer(raw)
    rescue ArgumentError
      log_red("Input is not a valid integer, please try again")
      next
    end
    if value <= 0
      log_red("Provided number is not positive, please try again")
      next
    end
    return value
  end
end

def perform_signup(email, password, display_name, referral_code)
  uri = URI.parse("https://qpzjnejmxtifajnkfuoh.supabase.co/auth/v1/signup?redirect_to=https%3A%2F%2Fcryptowave.blog%2F")
  headers = {
    "accept" => "*/*",
    "accept-encoding" => "gzip, deflate, br, zstd",
    "accept-language" => "ja,en-US;q=0.9,en;q=0.8",
    "apikey" => "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFwempuZWpteHRpZmFqbmtmdW9oIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjcyMjExOTMsImV4cCI6MjA4Mjc5NzE5M30.lVbiUI5_WIkI8mACai8V5fRdEzcXbJ8_z1L3Ar5ZulI",
    "authorization" => "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFwempuZWpteHRpZmFqbmtmdW9oIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjcyMjExOTMsImV4cCI6MjA4Mjc5NzE5M30.lVbiUI5_WIkI8mACai8V5fRdEzcXbJ8_z1L3Ar5ZulI",
    "cache-control" => "no-cache",
    "content-type" => "application/json;charset=UTF-8",
    "origin" => "https://cryptowave.blog",
    "pragma" => "no-cache",
    "referer" => "https://cryptowave.blog/",
    "sec-ch-ua" => "\"Microsoft Edge\";v=\"143\", \"Chromium\";v=\"143\", \"Not A(Brand\";v=\"24\"",
    "sec-ch-ua-mobile" => "?0",
    "sec-ch-ua-platform" => "\"Windows\"",
    "sec-fetch-dest" => "empty",
    "sec-fetch-mode" => "cors",
    "sec-fetch-site" => "cross-site",
    "user-agent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0",
    "x-client-info" => "supabase-js-web/2.89.0",
    "x-supabase-api-version" => "2024-01-01"
  }
  payload = {
    "email" => email,
    "password" => password,
    "data" => {
      "display_name" => display_name,
      "referral_code" => referral_code
    },
    "gotrue_meta_security" => {},
    "code_challenge" => nil,
    "code_challenge_method" => nil
  }
  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true
  request = Net::HTTP::Post.new(uri.request_uri, headers)
  request.body = JSON.dump(payload)
  begin
    response = http.request(request)
  rescue StandardError
    log_red("Network error detected during signup request")
    return false
  end
  if response.code == "200" || response.code == "201"
    log_green("Remote service returned successful status")
    true
  else
    log_red("Remote service returned failure status code " + response.code.to_s)
    false
  end
end

def main
  set_title
  banner
  referral_code = request_referral_code
  account_total = request_account_count
  log_yellow("Referral code accepted")
  log_yellow("Planned account generation count " + account_total.to_s)
  index = 1
  while index <= account_total
    log_yellow("Starting registration for account number " + index.to_s)
    email = generate_random_email
    password = generate_random_password
    display_name = generate_display_name
    log_yellow("Generated email " + email)
    log_yellow("Generated display name " + display_name)
    log_green("Submitting signup request to remote interface")
    success = perform_signup(email, password, display_name, referral_code)
    if success
      log_green("Account number " + index.to_s + " registration finished with successful result")
    else
      log_red("Account number " + index.to_s + " registration finished with failure result")
    end
    index += 1
  end
  log_green("All planned registration tasks have been processed")
end

if __FILE__ == $0
  main
end
